const _global = 'assets/icons/global/';
const _tasks = 'assets/icons/tasks/';

sealed class AppIcons {
  // ------------------  Global Folder  ----------------------- //
  static const tasks = '${_global}tasks.svg';
  static const expense = '${_global}expense.svg';
  static const create = '${_global}create.svg';
  static const calendar = '${_global}calendar.svg';
  static const stats = '${_global}stats.svg';
  static const logo = '${_global}logo.svg';
  static const apple = '${_global}apple.svg';
  static const eyeOff = '${_global}eye_off.svg';
  static const eyeOn = '${_global}eye_on.svg';
  static const facebook = '${_global}facebook.svg';
  static const google = '${_global}google.svg';

  // ------------------  Tasks Folder  ----------------------- //
  static const hamburger = '${_tasks}hamburger.svg';
  static const note = '${_tasks}note.svg';
  static const notification = '${_tasks}notification.svg';
  static const search = '${_tasks}search.svg';
  static const filter = '${_tasks}filter.svg';
}
